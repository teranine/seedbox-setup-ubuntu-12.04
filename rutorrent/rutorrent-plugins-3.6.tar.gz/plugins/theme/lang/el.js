﻿/*
 * PLUGIN THEME
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.themeStandard	= "Προκαθορισμένο";
 theUILang.theme		= "Θέμα";

thePlugins.get("theme").langLoaded();