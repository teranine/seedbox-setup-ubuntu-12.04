﻿/*
 * PLUGIN THROTTLE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.throttles		= "Kanały";
 theUILang.throttle		= "Kanał";
 theUILang.mnuThrottle		= "Ustaw kanał";
 theUILang.mnuUnlimited 	= "Brak kanału";
 theUILang.channelName		= "Nazwa";
 theUILang.channelDefault	= "Kanał domyślny";

thePlugins.get("throttle").langLoaded();