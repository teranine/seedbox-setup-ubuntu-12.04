﻿/*
 * PLUGIN SOURCE
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.getSource		= "Λήψη αρχείου .torrent";
 theUILang.cantFindTorrent	= "Το πηγαίο αρχείο torrent για αυτή τη λήψη δεν βρέθηκε.";

thePlugins.get("source").langLoaded();