﻿/*
 * PLUGIN SOURCE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.getSource		= "Получить .torrent";
 theUILang.cantFindTorrent	= "Исходный .torrent файл недоступен для данной закачки.";

thePlugins.get("source").langLoaded();