﻿/*
 * PLUGIN DATADIR
 *
 * Slovak language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Save to";
 theUILang.DataDirMove		= "Move data files";
 theUILang.datadirDlgCaption	= "Torrent Data Directory";
 theUILang.datadirDirNotFound	= "DataDir plugin: Invalid directory";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operation fail";
 theUILang.datadirPHPNotFound	= "DataDir plugin: rTorrent user can't access php interpreter. Plugin will not work.";

thePlugins.get("datadir").langLoaded();