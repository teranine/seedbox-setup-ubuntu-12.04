﻿/*
 * PLUGIN FEEDS
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.feedAll		= "所有 torrents";
 theUILang.feedCompleted	= "已完成 torrents";
 theUILang.feedDownloading	= "下载中 torrents";
 theUILang.feedActive		= "活动 torrents";
 theUILang.feedInactive 	= "停用 torrents";
 theUILang.feedError		= "错误 torrents";

thePlugins.get("feeds").langLoaded();