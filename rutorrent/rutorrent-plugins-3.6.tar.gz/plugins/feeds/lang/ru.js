﻿/*
 * PLUGIN FEEDS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.feedAll		= "Все закачки";
 theUILang.feedCompleted	= "Завершенные закачки";
 theUILang.feedDownloading	= "Загружаемые закачки";
 theUILang.feedActive		= "Активные закачки";
 theUILang.feedInactive 	= "Неактивные закачки";
 theUILang.feedError		= "Закачки с ошибками";

thePlugins.get("feeds").langLoaded();