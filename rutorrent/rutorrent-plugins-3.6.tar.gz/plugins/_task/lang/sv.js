﻿/*
 * PLUGIN _TASK
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.tskCommand		= "Körs...";
 theUILang.tskCommandDone	= "Färdig.";
 theUILang.tskConsole		= "Konsoll";
 theUILang.tskErrors		= "Diagnostik";

thePlugins.get("_task").langLoaded();
