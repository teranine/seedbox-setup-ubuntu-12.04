﻿/*
 * PLUGIN TRAFFIC
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.traf 		= "Trafic";
 theUILang.perDay		= "Par Jour";
 theUILang.perMonth		= "Par mois";
 theUILang.perYear		= "Par an";
 theUILang.allTrackers		= "Tous les trackers";
 theUILang.ClearButton		= "Vider";
 theUILang.ClearQuest		= "Voulez-vous réellement supprimer les statistiques pour le(s) tracker(s) sélectionné(s) ?";
 theUILang.selectedTorrent	= "Du torrent";
 theUILang.ratioDay		= "Ratio/jour";
 theUILang.ratioWeek		= "Ratio/semaine";
 theUILang.ratioMonth		= "Ratio/mois";
