﻿/*
 * PLUGIN TRAFFIC
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.traf 		= "Трафік";
 theUILang.perDay		= "За добу";
 theUILang.perMonth		= "За місяць";
 theUILang.perYear		= "За рік";
 theUILang.allTrackers		= "Усі трекери";
 theUILang.ClearButton		= "Очистити";
 theUILang.ClearQuest		= "Справді очистити статистику для вибраних трекерів?";
 theUILang.selectedTorrent	= "Вибраний торент";
 theUILang.ratioDay		= "Коефіцієнт/день";
 theUILang.ratioWeek		= "Коефіцієнт/тиждень";
 theUILang.ratioMonth		= "Коефіцієнт/місяць";
