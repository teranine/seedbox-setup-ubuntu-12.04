﻿/*
 * PLUGIN FILEDROP
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Плагін filedrop: ваш браузер не підтримує вивантаження файлів за допомогою HTML5. Плагін вимкнено.";
 theUILang.tooManyFiles 	= "Плагін filedrop: забагато файлів. Їх кількість не повинна перевищувати ";
 theUILang.fileTooLarge 	= "завеликий. Розмір файлу не повинен перевищувати ";

thePlugins.get("filedrop").langLoaded();