﻿/*
 * PLUGIN FILEDROP
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Votre navigateur ne support pas l'envoi de fichier en HTML5. Plugin désactivé.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Trop de fichiers. Doit être <= ";
 theUILang.fileTooLarge 	= "est trop grand. Veuillez envoyer des fichiers jusqu'à";

thePlugins.get("filedrop").langLoaded();