﻿/*
 * PLUGIN FILEDROP
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.doesntSupportHTML5	= "Insticksprogram, filedrop: Din webbläsare stöder inte filuppladdningar med HTML5. Insticksprogrammet inaktiverades.";
 theUILang.tooManyFiles 	= "Insticksprogram, filedrop: För många filer. Skall vara <= ";
 theUILang.fileTooLarge 	= "är för stor. Var god ladda upp filer under";

thePlugins.get("filedrop").langLoaded();
